package com.example.mystudent;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ItemAdapter extends ArrayAdapter<Person> {
    public ItemAdapter(Context context, ArrayList<Person> list) {
        super(context, 0, list);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.itemlayout, parent, false);
        }

        Person person = getItem(position);

        ImageView imageView = convertView.findViewById(R.id.imageView2);
        TextView nameText = convertView.findViewById(R.id.textViewName);
        TextView idText = convertView.findViewById(R.id.textViewIdNo);
        TextView courseText = convertView.findViewById(R.id.textViewCourse);

        if (person.getImageUri() != null) {
            imageView.setImageURI(person.getImageUri());
        }
        nameText.setText(person.getFullName());
        idText.setText(String.valueOf(person.getId()));
        courseText.setText(person.getCourse() != null ? person.getCourse() : "N/A");

        return convertView;
    }
}