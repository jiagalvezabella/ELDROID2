package com.example.mystudent;

import android.app.ComponentCaller;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

        ListView lv;
        ArrayList<Person> list = new ArrayList<Person>();
        ItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

       

        lv = findViewById(R.id.listView);
        adapter = new ItemAdapter(this,list);
        lv.setAdapter(adapter);


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent = new Intent(this, MainActivity2.class);
        startActivityForResult(intent,0);
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Toast.makeText(this, "onActivityResult: request=" + requestCode + ", result=" + resultCode, Toast.LENGTH_SHORT).show(); // Add this
        if (requestCode == 0 && resultCode == RESULT_OK) {
            Bundle b = data.getExtras();
            Uri imageUri = b.getParcelable("image");
            String idNo = b.getString("idNo");
            String lastName = b.getString("lastName");
            String firstName = b.getString("firstName");
            String course = b.getString("course");
            // Ignore level for now

            Person person = new Person(imageUri, Integer.parseInt(idNo.isEmpty() ? "0" : idNo),
                    firstName, lastName, course);
            list.add(person);
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Item added, list size: " + list.size(), Toast.LENGTH_SHORT).show(); // Add this
        }
    }
}