package com.example.mystudent;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    ImageView iv;
    EditText txtName; // editText1 (ID No)
    EditText txtLastName; // editTextLastName
    EditText txtFirstName; // editTextFirstName
    EditText txtCourse; // editTextCourse
    EditText txtLevel; // editTextLevel
    Button btnSave, btnCancel;
    Uri imageUri;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK) {
            imageUri = data.getData();
            iv.setImageURI(imageUri);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        // Initialize all views
        iv = findViewById(R.id.imageView);
        txtName = findViewById(R.id.editText1);
        txtLastName = findViewById(R.id.editTextLastName);
        txtFirstName = findViewById(R.id.editTextFirstName);
        txtCourse = findViewById(R.id.editTextCourse);
        txtLevel = findViewById(R.id.editTextLevel);
        btnSave = findViewById(R.id.button);
        btnCancel = findViewById(R.id.button2);

        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 100);
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String idNo = txtName.getText().toString();
                String lastName = txtLastName.getText().toString();
                String firstName = txtFirstName.getText().toString();
                String course = txtCourse.getText().toString();
                String level = txtLevel.getText().toString();

                if (imageUri != null && !idNo.isEmpty()) {
                    Intent intent = new Intent();
                    intent.putExtra("image", imageUri);
                    intent.putExtra("idNo", idNo);
                    intent.putExtra("lastName", lastName);
                    intent.putExtra("firstName", firstName);
                    intent.putExtra("course", course);
                    intent.putExtra("level", level);
                    setResult(RESULT_OK, intent);
                    Toast.makeText(MainActivity2.this, "Saving data", Toast.LENGTH_SHORT).show(); // Add this
                    finish();
                } else {
                    Toast.makeText(MainActivity2.this, "Image or ID missing", Toast.LENGTH_SHORT).show(); // Add this
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}