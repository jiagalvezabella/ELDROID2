package com.example.mystudent;

import android.net.Uri;

public class Person {
    private int id;
    private Uri imageUri;
    private String firstName;
    private String lastName;
    private String course;
    private String level;

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public Person(Uri imageUri, int id, String firstName, String lastName, String course) {
        this.imageUri = imageUri;
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.course = course;
    }

    public Person(String firstName, String lastName) {

        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Person(Uri imageUri, String firstName, String lastName) {
        this.imageUri = imageUri;
        this.firstName = firstName;
        this.lastName = lastName;
    }


    public String getFullName() { return firstName + " " + lastName; }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Uri getImageUri() {
        return imageUri;
    }

    public void setImageUri(Uri imageUri) {
        this.imageUri = imageUri;
    }

}
